﻿// This file is used by Code Analysis to maintain SuppressMessage
// attributes that are applied to this project.
// Project-level suppressions either have no target or are given
// a specific target and scoped to a namespace, type, member, etc.

using System.Diagnostics.CodeAnalysis;

[assembly: SuppressMessage( "Style", "IDE0047:Remove unnecessary parentheses", Justification = "<Pending>", Scope = "member", Target = "~M:RVJ.Core.Person.Equals(System.Object)~System.Boolean" )]
[assembly: SuppressMessage( "Style", "IDE0047:Remove unnecessary parentheses", Justification = "<Pending>", Scope = "member", Target = "~M:RVJ.Core.Person.Equals(System.Object,System.Object)~System.Boolean" )]
[assembly: SuppressMessage( "Style", "IDE0047:Remove unnecessary parentheses", Justification = "<Pending>", Scope = "member", Target = "~M:RVJ.Core.Person.ReferenceEquals(System.Object,System.Object)~System.Boolean" )]
[assembly: SuppressMessage( "Style", "IDE0059:Unnecessary assignment of a value", Justification = "<Pending>", Scope = "member", Target = "~M:RVJ.Core.Person.ReferenceEquals(System.Object,System.Object)~System.Boolean" )]
[assembly: SuppressMessage( "Style", "IDE0047:Remove unnecessary parentheses", Justification = "<Pending>", Scope = "member", Target = "~M:RVJ.Core.Person.op_GreaterThan(RVJ.Core.Person,RVJ.Core.Person)~System.Boolean" )]
[assembly: SuppressMessage( "Style", "IDE0011:Add braces", Justification = "<Pending>", Scope = "member", Target = "~M:RVJ.Core.Person.op_GreaterThan(RVJ.Core.Person,RVJ.Core.Person)~System.Boolean" )]
[assembly: SuppressMessage( "Style", "IDE0059:Unnecessary assignment of a value", Justification = "<Pending>", Scope = "member", Target = "~M:RVJ.Core.Person.op_GreaterThan(RVJ.Core.Person,RVJ.Core.Person)~System.Boolean" )]
[assembly: SuppressMessage( "Style", "IDE0047:Remove unnecessary parentheses", Justification = "<Pending>", Scope = "member", Target = "~M:RVJ.Core.Business.Person.Equals(System.Object,System.Object)~System.Boolean" )]
[assembly: SuppressMessage( "Style", "IDE0047:Remove unnecessary parentheses", Justification = "<Pending>", Scope = "member", Target = "~M:RVJ.Core.Business.Person.ReferenceEquals(System.Object,System.Object)~System.Boolean" )]
[assembly: SuppressMessage( "Style", "IDE0047:Remove unnecessary parentheses", Justification = "<Pending>", Scope = "member", Target = "~M:RVJ.Core.Business.Person.Equals(System.Object)~System.Boolean" )]
