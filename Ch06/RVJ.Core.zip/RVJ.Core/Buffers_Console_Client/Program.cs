﻿#region Namespaces

using System;
using System.Threading;
using System.Reflection;
using System.Reflection.Emit;

using RVJ.Core.Business;



#endregion

namespace Buffers_Console_Client {
    public static class Program : Object {

        public static void Main() {


            Person _personA = new Person();
            Person _personB = new Person();

            #region Some examples for Equals operation

            // Must be false
            Boolean _areEquals = _personA.Equals( _personB );

            // Must be false
            _areEquals = _personB.Equals( _personA );

            // Must be false
            _areEquals = _personA.Equals( null );

            // Must be false
            _areEquals = _personB.Equals( null );

            // Must be false
            _areEquals = _personA.Equals( new Object() );

            // Must be false
            _areEquals = _personB.Equals( new Object() );

            // Must be false
            _areEquals = _personA.Equals( ( _ = new Object() ) );

            // Must be false
            _areEquals = _personB.Equals( ( _ = new Object() ) );

            // Must be false
            _areEquals = _personA.Equals( ( _ = new Person() ) );

            // Must be false
            _areEquals = _personB.Equals( ( _ = new Person() ) );

            // Must be false
            _areEquals = _personA.Equals( ( _ = new Int32() ) );

            // Must be false
            _areEquals = _personB.Equals( ( _ = new Int32() ) );

            // Must be false
            _areEquals = _personA.Equals( ( _ = _personB ) );

            // Must be false
            _areEquals = _personB.Equals( ( _ = _personA ) );

            // Must be false
            _areEquals = ( _ = _personA ).Equals( _personB );

            // Must be false
            _areEquals = ( _ = _personB ).Equals( _personA );

            // Must be false
            _areEquals = Person.Equals( ( _ = _personA ), ( _ = _personB ) );

            // Must be false
            _areEquals = Person.Equals( ( _ = _personB ), ( _ = _personA ) );

            // Must be false
            _areEquals = _personA.Equals( null );

            // Must be false
            _areEquals = _personB.Equals( null );

            // Must be false
            _areEquals = _personA.Equals( new Object() );

            // Must be false
            _areEquals = _personB.Equals( new Object() );

            // Must be false
            _areEquals = _personA.Equals( ( _ = new Object() ) );

            // Must be false
            _areEquals = _personB.Equals( ( _ = new Object() ) );

            // Must be false
            _areEquals = Person.ReferenceEquals( _personA, ( _ = new Int32() ) );

            // Must be false
            _areEquals = Person.ReferenceEquals( _personB, ( _ = new Int32() ) );

            // Must be false
            _areEquals = Person.ReferenceEquals( _personA, null );

            // Must be false
            _areEquals = Person.ReferenceEquals( _personB, null );

            // Must be false
            _areEquals = Person.ReferenceEquals( _personA, new Object() );

            // Must be false
            _areEquals = Person.ReferenceEquals( _personB, new Object() );

            // Must be false
            _areEquals = Person.ReferenceEquals( _personA, ( _ = new Object() ) );

            // Must be false
            _areEquals = Person.ReferenceEquals( _personB, ( _ = new Object() ) );

            // Must be true
            _areEquals = _personA.Equals( _personA );

            // Must be true
            _areEquals = _personB.Equals( _personB );

            // Must be true
            _areEquals = _personA.Equals( _ = _personA );

            // Must be true
            _areEquals = _personB.Equals( _ = _personB );

            // Must be true
            _areEquals = ( _ = _personA ).Equals( _personA );

            // Must be true
            _areEquals = ( _ = _personB ).Equals( _personB );

            // Must be true
            _areEquals = Person.ReferenceEquals( ( _ = _personA ), _personA );

            // Must be true
            _areEquals = Person.ReferenceEquals( ( _ = _personB ), _personB );

            // Must be true
            _areEquals = Person.ReferenceEquals( _personA, _personA );

            // Must be true
            _areEquals = Person.ReferenceEquals( _personB, _personB );

            #endregion

            return;
        }
    };
};
