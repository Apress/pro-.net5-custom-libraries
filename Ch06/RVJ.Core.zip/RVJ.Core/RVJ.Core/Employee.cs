﻿#region Namespaces/Assemblies

using System;

#if DEBUG
using System.Diagnostics;
#endif

#endregion

namespace RVJ.Core.Business {

    public class Employee : Person {

        /*
         * Static constructor provided explicitly by the data type.
         */
        static Employee() {
            return;
        }

        // Default constructor provided explicitly by the data type.
        public Employee() : base() { return; }

        ~Employee() {
            return;
        }


    };
};