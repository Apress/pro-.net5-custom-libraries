﻿#region Namespaces/Assemblies

using System;

#if DEBUG
using System.Diagnostics;
#endif

#endregion

namespace RVJ.Core.Business {

    public class Person : System.Object {


        #region Private fields

        private readonly Guid _internal_ID;
        private UInt32 _age;
        private String _firstName;
        private String _lastName;

        #endregion

        #region Constructor(s)
        public Person() : base() {

            this._internal_ID = Guid.NewGuid();
            this._age = new UInt32();
            this._firstName = String.Empty;
            this._lastName = String.Empty;

            return;
        }

        static Person() {



#if DEBUG
            Debug.WriteLine( "Class (static) constructor called.", "RVJ.Core.Business.Person" );
#endif

            return;
        }
        #endregion

        #region Destructor
        ~Person() {
            return;
        }
        #endregion

        #region Override System.Object.Equals()

        public override Boolean Equals( System.Object instance ) {

            /*
			 *
			 * An instance of Person or derivation.
			 */
            Person _another = ( instance as Person );
            Boolean _equals = ( ( _another != null ) && ( this._internal_ID.Equals( _another._internal_ID ) && System.Object.ReferenceEquals( this, _another ) ) );

            return _equals;
        }

        public new static Boolean Equals( System.Object first, System.Object second ) {

            /*
			 *
			 * An instance of Person or derivation.
			*/
            Person _first = ( first as Person );
            Person _second = ( second as Person );

            //Boolean _equals = ( ( _first != null ) && ( _second != null ) && ( ( _first._internal_ID == _second._internal_ID ) ) && System.Object.ReferenceEquals( _first, _second ) );

            /*
			 * This expression implements the expression above.
			 */
            return ( ( _first != null ) ? _first.Equals( _second ) : _second.Equals( _first ) );
        }


        #endregion

        #region Specialized implementation for System.Object.ReferenceEquals()
        public new static System.Boolean ReferenceEquals( System.Object first, System.Object second ) {

            /*
			 * An instance of Person or derivation.
			 */

            Person _first = ( first as Person );
            Person _second = ( second as Person );
            Boolean _equals = ( ( ( _first != null ) && ( _second != null ) ) && ( _first._internal_ID.Equals( _second._internal_ID ) && System.Object.ReferenceEquals( _first, _second ) ) );


            return _equals;
        }
        #endregion

        #region Overrides System.Object.GetHashCode()
        public override Int32 GetHashCode() {
            /*
		 * When using the instance method System.HashCode.ToHashCode() we are using
		 * an instance of System.HashCode value type, and calling
		 *  System.HashCode.ToHashCode() at least once for each instance of
		 *  System.HashCode value type, is a requirement for the .NET System.HashCode
		 *  value type works correctly.
		 */

            HashCode _hashOne = new HashCode();
            HashCode _hashTwo = new HashCode();
            HashCode _hashResult = new HashCode();

            _hashOne.Add<Byte []>( this._internal_ID.ToByteArray() );
            _hashTwo.Add<Byte []>( Guid.NewGuid().ToByteArray() );

            _hashResult.Add<Int32>( HashCode.Combine<Int32, Int32, Int32>( _hashResult.ToHashCode(), _hashOne.ToHashCode(), _hashTwo.ToHashCode() ) );

            return _hashResult.ToHashCode();

            /*
			 *
			 * When using the static method System.HashCode.Combine() we are not using an instance of System.HashCode value type.
			 * return System.HashCode.Combine<Int32>( base.GetHashCode() );
			 *
			 */




            /*
			 * return base.GetHashCode();
			 */
        }
        #endregion

        #region Operators

        public static Boolean operator ==( Person first, Person second ) {
            return Person.ReferenceEquals( first, second );
        }
        public static Boolean operator !=( Person first, Person second ) {
            return !Person.ReferenceEquals( first, second );
        }

        public static Person operator >( Person first, Person second ) {


            // An exercise for the reader.

            return null;
        }

        public static Person operator <( Person first, Person second ) {
            // An exercise for the reader.
            return null;
        }

        #endregion

        #region System.Object.ToString()
        public override System.String ToString() {
            /*
			 *  For now, this method does not have any custom implementation.
			 */
            return base.ToString();
        }

        #endregion

        #region Public Properties
        public UInt32 Age {
            set {
                this._age = value;
            }
            get {
                return this._age;
            }
        }
        public String FirstName {
            set {
                this._firstName = value;
            }
            get {
                return this._firstName;
            }
        }
        public String LastName {
            set {
                this._lastName = value;
            }
            get {
                return this._lastName;
            }
        }

        #endregion

    };

};