﻿#region Namespaces
using System;
#endregion

namespace ConsoleClient {
	public static class Program : System.Object {
		public static void Main() {
			return;
		}
	};
};
