﻿

namespace RVJ.Core {
	public class Buffer {
	}
};
