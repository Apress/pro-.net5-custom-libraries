﻿#region Namespaces/Assemblies

using System;

#if DEBUG
using System.Diagnostics;
#endif

using System.Threading;
using System.Reflection;
using System.Reflection.Emit;

#endregion

namespace RVJ.Core {
    public class AssemblyBuilder {
        #region Private fields

        private String _assemblyName;


        #endregion

        public AssemblyBuilder() {

            this._assemblyName = String.Empty;

            return;
        }
    };
};
