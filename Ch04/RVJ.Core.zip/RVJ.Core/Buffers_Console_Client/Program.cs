﻿#region Namespaces

using System;
using System.Reflection;
using System.Reflection.Emit;

#endregion

namespace Buffers_Console_Client {
    public static class Program : Object {

        public static void CreateType( String assemblyName, String transientModuleName = "RVJ.Core.Business" ) {

            AssemblyName _assemblyName = new AssemblyName( assemblyName );
            AssemblyBuilder _assemblyBuilder =   AssemblyBuilder.DefineDynamicAssembly( _assemblyName, AssemblyBuilderAccess.RunAndCollect );


            ModuleBuilder _moduleBuilder = _assemblyBuilder.DefineDynamicModule( transientModuleName );

            TypeBuilder _newExtendedDataType = _moduleBuilder.DefineType( "RVJ.Core.Business.Employee", TypeAttributes.Class | TypeAttributes.Public | TypeAttributes.Serializable | TypeAttributes.AutoLayout  | TypeAttributes.SpecialName | TypeAttributes.UnicodeClass );


            ConstructorBuilder _nonDefaultConstructor = _newExtendedDataType.DefineConstructor( MethodAttributes.Public | MethodAttributes.SpecialName | MethodAttributes.HideBySig | MethodAttributes.RTSpecialName | MethodAttributes.FamORAssem | MethodAttributes.CheckAccessOnOverride, CallingConventions.Standard, new Type [] { } );




            ConstructorBuilder _defaultConstructor = _newExtendedDataType.DefineDefaultConstructor( MethodAttributes.Public | MethodAttributes.SpecialName | MethodAttributes.HideBySig | MethodAttributes.RTSpecialName | MethodAttributes.FamORAssem | MethodAttributes.CheckAccessOnOverride );




            return;
        }
        public static void Main() {


            /*
             * CreateType() method receives "RVJ.Core.Business" as the name for the dynamic assembly and the same name will be used for the transient module name.
             * A transient module name exists only in memory, it is not persisted in a DLL file.
             */

            Program.CreateType("RVJ.Core.Business");


            return;
        }
    };
};
